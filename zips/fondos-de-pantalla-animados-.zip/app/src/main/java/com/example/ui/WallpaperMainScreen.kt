package com.example.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.AdvancedSettingsCard
import com.example.ui.components.AppSettingsDialog
import com.example.ui.components.ApplyWallpaperBottomBar
import com.example.ui.components.DayNightWallpaperCard
import com.example.ui.components.MainHeaderBar
import com.example.ui.components.OptimizationLoadingDialog
import com.example.ui.components.RestoreWallpaperCard
import com.example.ui.components.SelectWallpaperDialog
import com.example.ui.components.SoundControlsCard
import com.example.ui.components.TikTokDownloadCard
import com.example.ui.components.TikTokDownloadDialog
import com.example.ui.components.VideoPreviewCard
import com.example.ui.components.VisualFiltersCard
import com.example.ui.components.WallpaperStatusCard
import com.example.ui.components.WeatherSolarCard
import com.example.ui.helpers.DownloadState
import com.example.ui.helpers.OptimizationState

enum class ScreenState {
    GALLERY,
    ENGINE_SETTINGS,
    APP_SETTINGS
}

@Composable
fun WallpaperMainScreen(
    viewModel: WallpaperViewModel
) {
    val context = LocalContext.current
    val config by viewModel.configState.collectAsState()
    val hasOriginalBackup by viewModel.hasOriginalBackup.collectAsState()
    val videoResolutionInfo by viewModel.videoResolutionInfo.collectAsState()
    val downloadState by viewModel.downloadState.collectAsState()
    val optimizationState by viewModel.optimizationState.collectAsState()
    val savedWallpapers by viewModel.savedWallpapers.collectAsState()

    var isWallpaperActive by remember { mutableStateOf(false) }
    var currentScreen by remember { mutableStateOf(ScreenState.GALLERY) }
    var showTikTokDialog by remember { mutableStateOf(false) }

    var pickForTarget by remember { mutableStateOf<String?>(null) } // "DAY", "NIGHT", etc.
    var showSelectWallpaperDialogForTarget by remember { mutableStateOf<String?>(null) }

    // Video Gallery Picker Launcher
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.backupOriginalWallpaperIfNeeded(context)
            viewModel.onVideoSelected(context, uri, context.contentResolver)
            currentScreen = ScreenState.ENGINE_SETTINGS
        }
    }

    // Day/Night & Weather Specific Video Picker Launcher
    val dayNightVideoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.backupOriginalWallpaperIfNeeded(context)
            when (pickForTarget) {
                "DAY" -> {
                    viewModel.onDayVideoSelected(context, uri.toString(), context.contentResolver)
                    viewModel.onDayNightEnabledChanged(true)
                    Toast.makeText(context, "Vídeo de Día asignado con éxito", Toast.LENGTH_SHORT).show()
                }
                "NIGHT" -> {
                    viewModel.onNightVideoSelected(context, uri.toString(), context.contentResolver)
                    viewModel.onDayNightEnabledChanged(true)
                    Toast.makeText(context, "Vídeo de Noche asignado con éxito", Toast.LENGTH_SHORT).show()
                }
                "SUNNY" -> {
                    viewModel.onSunnyVideoSelected(context, uri.toString(), context.contentResolver)
                    Toast.makeText(context, "Vídeo para Día Soleado asignado con éxito", Toast.LENGTH_SHORT).show()
                }
                "RAINY" -> {
                    viewModel.onRainyVideoSelected(context, uri.toString(), context.contentResolver)
                    Toast.makeText(context, "Vídeo para Día Lluvioso asignado con éxito", Toast.LENGTH_SHORT).show()
                }
                "CLOUDY" -> {
                    viewModel.onCloudyVideoSelected(context, uri.toString(), context.contentResolver)
                    Toast.makeText(context, "Vídeo para Día Nublado asignado con éxito", Toast.LENGTH_SHORT).show()
                }
                "SNOWY" -> {
                    viewModel.onSnowyVideoSelected(context, uri.toString(), context.contentResolver)
                    Toast.makeText(context, "Vídeo para Nieve asignado con éxito", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        isWallpaperActive = viewModel.isServiceActiveWallpaper(context)
        viewModel.checkOriginalBackup(context)
        viewModel.backupOriginalWallpaperIfNeeded(context)
    }

    LaunchedEffect(config.videoUri) {
        if (config.videoUri.isNotBlank()) {
            viewModel.detectVideoResolution(context, config.videoUri)
        }
    }

    // Optimization State Listener
    LaunchedEffect(optimizationState) {
        when (val state = optimizationState) {
            is OptimizationState.Success -> {
                Toast.makeText(
                    context,
                    "¡Vídeo reducido permanentemente a ${state.downscaledHeight}p conservando nitidez nativa!",
                    Toast.LENGTH_LONG
                ).show()
                viewModel.resetOptimizationState()
            }
            is OptimizationState.Error -> {
                Toast.makeText(context, state.message, Toast.LENGTH_LONG).show()
                viewModel.resetOptimizationState()
            }
            else -> {}
        }
    }

    // Loading Screen for Rust Downscaling Processing
    if (optimizationState is OptimizationState.Processing) {
        OptimizationLoadingDialog(
            optimizationState = optimizationState as OptimizationState.Processing,
            onDismissRequest = {}
        )
    }

    // TikTok Download Listener & Dialog
    LaunchedEffect(downloadState) {
        if (downloadState is DownloadState.Success) {
            showTikTokDialog = false
            Toast.makeText(context, "¡Vídeo descargado con éxito! Abriendo editor...", Toast.LENGTH_SHORT).show()
            currentScreen = ScreenState.ENGINE_SETTINGS
            viewModel.resetDownloadState()
        }
    }

    if (showTikTokDialog) {
        TikTokDownloadDialog(
            downloadState = downloadState,
            onDismissRequest = { showTikTokDialog = false },
            onDownloadRequested = { url ->
                viewModel.downloadTikTokVideo(context, url)
            },
            onResetDownloadState = {
                viewModel.resetDownloadState()
            }
        )
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (currentScreen == ScreenState.ENGINE_SETTINGS) {
                ApplyWallpaperBottomBar(
                    hasVideoSelected = config.videoUri.isNotBlank(),
                    onApplyClicked = {
                        if (config.videoUri.isBlank()) {
                            Toast.makeText(
                                context,
                                "Por favor elige primero un vídeo de la galería",
                                Toast.LENGTH_LONG
                            ).show()
                            videoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        } else {
                            viewModel.openWallpaperPicker(context)
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        when (currentScreen) {
            ScreenState.GALLERY -> {
                WallpaperGalleryScreen(
                    savedWallpapers = savedWallpapers,
                    hasOriginalBackup = hasOriginalBackup,
                    activeVideoUri = config.videoUri,
                    onApplyWallpaper = { savedItem ->
                        viewModel.applySavedWallpaper(savedItem, context.contentResolver)
                        viewModel.openWallpaperPicker(context)
                    },
                    onRestoreOriginalStaticWallpaper = {
                        viewModel.restoreOriginalWallpaper(context) { success ->
                            if (success) {
                                isWallpaperActive = viewModel.isServiceActiveWallpaper(context)
                                Toast.makeText(
                                    context,
                                    "Fondo estático original restaurado correctamente",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    },
                    onDeleteWallpaper = { id ->
                        viewModel.deleteSavedWallpaper(id)
                    },
                    onOpenGalleryPicker = {
                        videoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    },
                    onOpenTikTokDialog = {
                        showTikTokDialog = true
                    },
                    onNavigateToSettings = {
                        currentScreen = ScreenState.ENGINE_SETTINGS
                    },
                    onOpenAppSettings = {
                        currentScreen = ScreenState.APP_SETTINGS
                    },
                    onSetAsDayWallpaper = { savedItem ->
                        viewModel.onDayVideoSelected(context, savedItem.uriString, context.contentResolver)
                        viewModel.onDayNightEnabledChanged(true)
                    },
                    onSetAsNightWallpaper = { savedItem ->
                        viewModel.onNightVideoSelected(context, savedItem.uriString, context.contentResolver)
                        viewModel.onDayNightEnabledChanged(true)
                    }
                )
            }
            ScreenState.APP_SETTINGS -> {
                AppSettingsScreen(
                    currentTheme = config.appTheme,
                    onThemeSelected = { newTheme ->
                        viewModel.onAppThemeChanged(newTheme)
                    },
                    onBackClicked = {
                        currentScreen = ScreenState.GALLERY
                    },
                    onNavigateToEngineSettings = {
                        currentScreen = ScreenState.ENGINE_SETTINGS
                    }
                )
            }
            ScreenState.ENGINE_SETTINGS -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .statusBarsPadding()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    // Back to Gallery Button Row
                    androidx.compose.foundation.layout.Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { currentScreen = ScreenState.GALLERY },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("back_to_gallery_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Regresar a la Galería",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Regresar a Galería",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Header Bar
                    MainHeaderBar(
                        onOpenSettings = { currentScreen = ScreenState.APP_SETTINGS }
                    )

                Spacer(modifier = Modifier.height(16.dp))

                // Active Wallpaper Status Card
                WallpaperStatusCard(isWallpaperActive = isWallpaperActive)

                Spacer(modifier = Modifier.height(20.dp))

                // TikTok Downloader Card
                TikTokDownloadCard(
                    downloadState = downloadState,
                    onDownloadRequested = { url ->
                        viewModel.downloadTikTokVideo(context, url)
                    },
                    onResetDownloadState = {
                        viewModel.resetDownloadState()
                    }
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Select Video CTA Button
                OutlinedButton(
                    onClick = {
                        videoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("select_video_button"),
                    shape = RoundedCornerShape(16.dp),
                    border = ButtonDefaults.outlinedButtonBorder.copy(width = 2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.VideoLibrary,
                        contentDescription = "Elegir vídeo de galería",
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (config.videoUri.isBlank()) "Seleccionar vídeo de Galería" else "Cambiar Vídeo de Galería",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Video Preview Card
                VideoPreviewCard(
                    config = config,
                    onSelectVideoClick = {
                        videoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    }
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Visual Filters & Real-Time Blur for Launcher Card
                VisualFiltersCard(
                    config = config,
                    onFiltersChanged = { blur, brightness, contrast, saturation, filterMode ->
                        viewModel.onVisualFiltersChanged(blur, brightness, contrast, saturation, filterMode)
                    }
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Weather & Real Solar Background Switcher Card
                WeatherSolarCard(
                    config = config,
                    onWeatherToggle = { viewModel.onWeatherEnabledChanged(it) },
                    onRealSolarToggle = { viewModel.onRealSolarEnabledChanged(it) },
                    onSelectSunnyVideoClicked = { showSelectWallpaperDialogForTarget = "SUNNY" },
                    onSelectRainyVideoClicked = { showSelectWallpaperDialogForTarget = "RAINY" },
                    onSelectCloudyVideoClicked = { showSelectWallpaperDialogForTarget = "CLOUDY" },
                    onSelectSnowyVideoClicked = { showSelectWallpaperDialogForTarget = "SNOWY" }
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Day / Night Dynamic Wallpaper Mode Card
                DayNightWallpaperCard(
                    config = config,
                    onDayNightToggle = { enabled ->
                        viewModel.onDayNightEnabledChanged(enabled)
                    },
                    onSelectDayVideoClicked = { showSelectWallpaperDialogForTarget = "DAY" },
                    onSelectNightVideoClicked = { showSelectWallpaperDialogForTarget = "NIGHT" },
                    savedWallpapers = savedWallpapers,
                    onEditVideoClicked = { uriStr ->
                        viewModel.editVideoByUri(context, uriStr, context.contentResolver)
                        currentScreen = ScreenState.ENGINE_SETTINGS
                        Toast.makeText(context, "Modificando ajustes del fondo...", Toast.LENGTH_SHORT).show()
                    }
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Sound Controls & Scale Settings
                SoundControlsCard(
                    config = config,
                    onVolumeChanged = { viewModel.onVolumeChanged(it) },
                    onMuteToggled = { viewModel.onMuteToggled() },
                    onScaleModeChanged = { viewModel.onScaleModeChanged(it) },
                    onSmartAudioFocusChanged = { viewModel.onSmartAudioFocusChanged(it) },
                    onAudioFadeEnabledChanged = { viewModel.onAudioFadeEnabledChanged(it) },
                    onNightQuietModeChanged = { viewModel.onNightQuietModeChanged(it) }
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Advanced NDK & Battery / Resolution Settings Card
                AdvancedSettingsCard(
                    config = config,
                    videoResolutionInfo = videoResolutionInfo,
                    onUseNativeEngineChanged = { viewModel.onUseNativeEngineChanged(it) },
                    onUseBatterySaverChanged = { viewModel.onUseBatterySaverChanged(it) },
                    onPauseOnLowBatteryChanged = { viewModel.onPauseOnLowBatteryChanged(it) },
                    onQualityResolutionIndexChanged = { viewModel.onQualityResolutionIndexChanged(it) },
                    onHardwareSharpnessChanged = { viewModel.onHardwareSharpnessChanged(it) },
                    onUseVideoCompressionChanged = { viewModel.onUseVideoCompressionChanged(it) }
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Restore & System Wallpaper Management Card
                RestoreWallpaperCard(
                    hasOriginalBackup = hasOriginalBackup,
                    onRestoreClicked = {
                        viewModel.restoreOriginalWallpaper(context) { success ->
                            if (success) {
                                isWallpaperActive = viewModel.isServiceActiveWallpaper(context)
                                Toast.makeText(
                                    context,
                                    "Fondo de pantalla estático restaurado con éxito",
                                    Toast.LENGTH_LONG
                                ).show()
                            } else {
                                Toast.makeText(
                                    context,
                                    "No se pudo restaurar el fondo original",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    },
                    onOpenSystemPickerClicked = {
                        viewModel.openSystemWallpaperPicker(context)
                    }
                )

                Spacer(modifier = Modifier.height(28.dp))
            }
        }
    }

    // Wallpaper Selection Dialog for Day / Night / Weather
    showSelectWallpaperDialogForTarget?.let { target ->
        val title = when (target) {
            "DAY" -> "Vídeo de Día"
            "NIGHT" -> "Vídeo de Noche"
            "SUNNY" -> "Vídeo Soleado"
            "RAINY" -> "Vídeo Lluvia"
            "CLOUDY" -> "Vídeo Nublado"
            "SNOWY" -> "Vídeo Nieve"
            else -> "Vídeo"
        }
        val currentUri = when (target) {
            "DAY" -> config.dayVideoUri
            "NIGHT" -> config.nightVideoUri
            "SUNNY" -> config.sunnyVideoUri
            "RAINY" -> config.rainyVideoUri
            "CLOUDY" -> config.cloudyVideoUri
            "SNOWY" -> config.snowyVideoUri
            else -> ""
        }

        SelectWallpaperDialog(
            title = "Seleccionar $title",
            targetName = title,
            savedWallpapers = savedWallpapers,
            currentAssignedUri = currentUri,
            dayVideoUri = config.dayVideoUri,
            nightVideoUri = config.nightVideoUri,
            onSelectSavedWallpaper = { savedItem ->
                when (target) {
                    "DAY" -> {
                        viewModel.onDayVideoSelected(context, savedItem.uriString, context.contentResolver)
                        viewModel.onDayNightEnabledChanged(true)
                        Toast.makeText(context, "Vídeo de Día asignado desde la Galería", Toast.LENGTH_SHORT).show()
                    }
                    "NIGHT" -> {
                        viewModel.onNightVideoSelected(context, savedItem.uriString, context.contentResolver)
                        viewModel.onDayNightEnabledChanged(true)
                        Toast.makeText(context, "Vídeo de Noche asignado desde la Galería", Toast.LENGTH_SHORT).show()
                    }
                    "SUNNY" -> {
                        viewModel.onSunnyVideoSelected(context, savedItem.uriString, context.contentResolver)
                        Toast.makeText(context, "Vídeo Soleado asignado desde la Galería", Toast.LENGTH_SHORT).show()
                    }
                    "RAINY" -> {
                        viewModel.onRainyVideoSelected(context, savedItem.uriString, context.contentResolver)
                        Toast.makeText(context, "Vídeo Lluvia asignado desde la Galería", Toast.LENGTH_SHORT).show()
                    }
                    "CLOUDY" -> {
                        viewModel.onCloudyVideoSelected(context, savedItem.uriString, context.contentResolver)
                        Toast.makeText(context, "Vídeo Nublado asignado desde la Galería", Toast.LENGTH_SHORT).show()
                    }
                    "SNOWY" -> {
                        viewModel.onSnowyVideoSelected(context, savedItem.uriString, context.contentResolver)
                        Toast.makeText(context, "Vídeo Nieve asignado desde la Galería", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            onOpenSystemPicker = {
                pickForTarget = target
                dayNightVideoPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                )
            },
            onDismissRequest = {
                showSelectWallpaperDialogForTarget = null
            }
        )
    }
}
}

